enum DeviceScreenType {
  Mobile,
  Tablet,
  Desktop,
}
