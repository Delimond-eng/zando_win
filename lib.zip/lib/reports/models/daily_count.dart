import 'package:flutter/widgets.dart';

class DailyCount {
  String title;
  double sum;
  IconData icon;

  DailyCount({this.title, this.sum, this.icon});
}
