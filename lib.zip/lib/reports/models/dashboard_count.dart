import 'package:flutter/widgets.dart';

class DashboardCount {
  String title;
  int countValue;
  IconData icon;
  Color color;

  DashboardCount({this.title, this.countValue, this.icon, this.color});
}
